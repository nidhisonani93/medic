<!-- footer.php -->
<footer style="background:#222; color:white; padding:40px 0; margin-top:50px;">
    <div style="max-width:1200px; margin:auto; padding:0 20px; display:flex; flex-wrap:wrap; justify-content:space-between;">

        <!-- About -->
        <div style="flex:1 1 250px; margin-bottom:20px;">
            <h2 style="font-size:22px; margin-bottom:10px;">About Us</h2>
            <p style="line-height:1.6;">
                We provide the best IT solutions, services and digital products for your business.
            </p>
        </div>

        <!-- Quick Links -->
        <div style="flex:1 1 200px; margin-bottom:20px;">
            <h2 style="font-size:22px; margin-bottom:10px;">Quick Links</h2>
            <ul style="list-style:none; padding:0; line-height:1.8;">
                <li><a href="index.php" style="color:white; text-decoration:none;">Home</a></li>
                <li><a href="about.php" style="color:white; text-decoration:none;">About</a></li>
                <li><a href="services.php" style="color:white; text-decoration:none;">Services</a></li>
                <li><a href="contact.php" style="color:white; text-decoration:none;">Contact</a></li>
            </ul>
        </div>

        <!-- Contact -->
        <div style="flex:1 1 250px; margin-bottom:20px;">
            <h2 style="font-size:22px; margin-bottom:10px;">Contact Info</h2>
            <p>Email: support@example.com</p>
            <p>Phone: +91 98765 43210</p>
            <p>Address: Bhavnagar, Gujarat</p>
        </div>
    </div>

    <div style="text-align:center; margin-top:20px; border-top:1px solid #444; padding-top:15px;">
        © 2025 All Rights Reserved | Designed by Your Company
    </div>
</footer>

<!-- RESPONSIVE CSS -->
<style>
@media(max-width:768px){
    footer div{
        text-align:center;
    }
}
</style>
