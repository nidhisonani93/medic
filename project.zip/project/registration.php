<?php
include 'db.php';

$msg = "";

if(isset($_POST['register'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

    mysqli_query($conn, "INSERT INTO users(name,email,password) VALUES('$name','$email','$pass')");
    $msg = "Registration Successful! <a href='index.php'>Login</a>";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Create Account</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
    body{
        background:#f0f2f5;
        font-family:Arial;
        margin:0;
        padding:0;
        display:flex;
        justify-content:center;
        align-items:center;
        height:100vh;
    }

    .box{
        width:90%;
        max-width:450px;
        background:white;
        padding:30px;
        border-radius:12px;
        box-shadow:0 0 20px rgba(0,0,0,0.1);
    }

    h2{
        text-align:center;
        margin-bottom:20px;
        font-size:26px;
    }

    label{
        font-weight:bold;
        display:block;
        margin-top:10px;
    }

    input{
        width:100%;
        padding:12px;
        border:1px solid #ccc;
        border-radius:8px;
        margin-top:5px;
        margin-bottom:10px;
    }

    button{
        width:100%;
        padding:12px;
        background:#007bff;
        color:white;
        border:none;
        border-radius:8px;
        font-size:16px;
        cursor:pointer;
        margin-top:10px;
    }

    button:hover{
        background:#0056b3;
    }

    .msg{
        margin-top:15px;
        text-align:center;
        font-size:16px;
        color:green;
        font-weight:600;
    }

</style>
</head>
<body>

<div class="box">
    <h2>Create Account</h2>

    <form method="POST">
        <label>Name:</label>
        <input type="text" name="name" required>

        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Password:</label>
        <input type="password" name="password" required>

        <button name="register">Register</button>
    </form>

    <?php if($msg != ""){ ?>
        <div class="msg"><?php echo $msg; ?></div>
    <?php } ?>
</div>

</body>
</html>
