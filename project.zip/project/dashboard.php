<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}
include 'header.php';
?>

<style>
.dashboard-container{
    max-width:1100px;
    margin:40px auto;
    padding:20px;
}
.feature-box{
    padding:25px;
    border-radius:12px;
    background:#fff;
    box-shadow:0 0 15px rgba(0,0,0,0.1);
    text-align:center;
    transition:.3s;
}
.feature-box:hover{
    transform:translateY(-5px);
}
.feature-icon{
    font-size:40px;
    color:#0d6efd;
}
.feature-title{
    margin-top:10px;
    font-size:20px;
    font-weight:bold;
}
.feature-box a{
    text-decoration:none;
    color:#000;
}
@media(max-width:768px){
    .feature-title{ font-size:18px; }
}
</style>

<div class="dashboard-container">

    <h2 class="text-center mb-4">Welcome, <?= $_SESSION['name']; ?></h2>

    <div class="row g-4">

        <!-- Upload Record -->
        <div class="col-md-4 col-sm-6">
            <a href="upload_record.php">
                <div class="feature-box">
                    <div class="feature-icon">📤</div>
                    <div class="feature-title">Upload Medical Record</div>
                </div>
            </a>
        </div>

        <!-- View Records -->
        <div class="col-md-4 col-sm-6">
            <a href="view_records.php">
                <div class="feature-box">
                    <div class="feature-icon">📁</div>
                    <div class="feature-title">View Records</div>
                </div>
            </a>
        </div>

        <!-- Order Medicine -->
        <div class="col-md-4 col-sm-6">
            <a href="order_medicine.php">
                <div class="feature-box">
                    <div class="feature-icon">💊</div>
                    <div class="feature-title">Order Medicine</div>
                </div>
            </a>
        </div>

        <!-- Emergency -->
        <div class="col-md-4 col-sm-6">
            <a href="emergency.php">
                <div class="feature-box">
                    <div class="feature-icon">🚑</div>
                    <div class="feature-title">Emergency Help</div>
                </div>
            </a>
        </div>

        <!-- AI Symptom Checker -->
        <div class="col-md-4 col-sm-6">
            <a href="ai_checker.php">
                <div class="feature-box">
                    <div class="feature-icon">🤖</div>
                    <div class="feature-title">AI Symptom Checker</div>
                </div>
            </a>
        </div>

        <!-- Logout -->
        <div class="col-md-4 col-sm-6">
            <a href="logout.php">
                <div class="feature-box">
                    <div class="feature-icon">🚪</div>
                    <div class="feature-title">Logout</div>
                </div>
            </a>
        </div>

    </div>
</div>

<?php include 'footer.php'; ?>
