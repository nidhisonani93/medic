<?php include 'header.php'; ?>

<div class="container mt-4">
    <h2>Our Doctors</h2>

    <ul>
        <li>Dr. Patel – General Physician</li>
        <li>Dr. Shah – Dermatologist</li>
        <li>Dr. Joshi – Dentist</li>
        <li>Dr. Mehta – Eye Specialist</li>
    </ul>
</div>

<?php include 'footer.php'; ?>
