<?php include 'header.php'; ?>

<div class="container mt-4">
    <h2>Lab Test Services</h2>

    <ul>
        <li>Complete Blood Count (CBC)</li>
        <li>Liver Function Test (LFT)</li>
        <li>Full Body Checkup</li>
        <li>Diabetes Test</li>
    </ul>
</div>

<?php include 'footer.php'; ?>
