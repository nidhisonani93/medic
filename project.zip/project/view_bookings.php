<?php include 'header.php'; ?>

<div class="container mt-4">
    <h2 class="mb-3">All Bookings</h2>

    <?php
    $conn = new mysqli("localhost", "root", "", "medic");
    $result = $conn->query("SELECT * FROM bookings ORDER BY id DESC");
    ?>

    <table class="table table-bordered table-striped">
        <tr>
            <th>ID</th><th>Name</th><th>Phone</th><th>Type</th><th>Service</th>
            <th>Date</th><th>Time</th><th>Message</th>
        </tr>

        <?php while($row = $result->fetch_assoc()){ ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['name'] ?></td>
            <td><?= $row['phone'] ?></td>
            <td><?= $row['booking_type'] ?></td>
            <td><?= $row['service'] ?></td>
            <td><?= $row['date'] ?></td>
            <td><?= $row['time'] ?></td>
            <td><?= $row['message'] ?></td>
        </tr>
        <?php } ?>
    </table>
</div>

<?php include 'footer.php'; ?>
