<?php include 'header.php'; ?>

<div class="container mt-4">
    <h2>Order Medicines</h2>

    <p>Upload Prescription & Order Medicines Home Delivery.</p>
</div>

<?php include 'footer.php'; ?>
