<?php
session_start();
include "db.php";

if(isset($_POST['book'])){
    $uid = $_SESSION['user_id'];
    $doc = $_POST['doctor'];
    $date = $_POST['date'];
    $time = $_POST['time'];

    mysqli_query($conn,"INSERT INTO appointments(user_id,doctor,date,time) 
        VALUES('$uid','$doc','$date','$time')");
    echo "Appointment Booked Successfully!";
}
?>

<form method="POST">
 Doctor Name: <input type="text" name="doctor"><br>
 Date: <input type="date" name="date"><br>
 Time: <input type="time" name="time"><br>
 <button name="book">Book</button>
</form>
