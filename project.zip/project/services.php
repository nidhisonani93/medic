<?php
// services.php - Responsive Services Page for Medic Platform
include 'header.php';
?>

<div class="container py-5">
    <h2 class="text-center fw-bold mb-4">Our Healthcare Services</h2>
    <p class="text-center mb-5">Medic provides a unified platform to manage your complete healthcare journey.</p>

    <div class="row g-4">

        <div class="col-md-3 col-sm-6">
            <div class="card text-center shadow-sm p-3 service-card">
                <img src="record.png" height="80" class="mx-auto">
                <h5 class="mt-3 fw-bold">Digital Health Records</h5>
                <p class="small">Securely store & access all your medical records in one place.</p>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="card text-center shadow-sm p-3 service-card">
                <img src="book.png" height="80" class="mx-auto">
                <h5 class="mt-3 fw-bold">Doctor Appointments</h5>
                <p class="small">Book consultations with certified doctors anytime.</p>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="card text-center shadow-sm p-3 service-card">
                <img src="medicine.png" height="80" class="mx-auto">
                <h5 class="mt-3 fw-bold">Buy Medicines</h5>
                <p class="small">Order medicines from trusted pharmacies at your doorstep.</p>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="card text-center shadow-sm p-3 service-card">
                <img src="emergency.png" height="80" class="mx-auto">
                <h5 class="mt-3 fw-bold">Emergency Services</h5>
                <p class="small">Quick access to ambulance & emergency medical help.</p>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="card text-center shadow-sm p-3 service-card">
                <img src="lab.png" height="80" class="mx-auto">
                <h5 class="mt-3 fw-bold">Lab Test Booking</h5>
                <p class="small">Schedule blood tests & receive your reports online.</p>
            </div>
        </div>

        <div class="col-md-3 col-sm-6">
            <div class="card text-center shadow-sm p-3 service-card">
                <img src="d.png" height="80" class="mx-auto">
                <h5 class="mt-3 fw-bold">AI Symptom Checker</h5>
                <p class="small">AI tool helps identify possible conditions instantly.</p>
            </div>
        </div>

    </div>
</div>

<?php include 'footer.php'; ?>