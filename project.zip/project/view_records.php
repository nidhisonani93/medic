<?php
session_start();
include "db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}

$uid = $_SESSION['user_id'];

$res = mysqli_query($conn,"SELECT * FROM records WHERE user_id=$uid");
?>
<!DOCTYPE html>
<html>
<head>
<title>Your Medical Records</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>

body{
    margin:0;
    padding:0;
    font-family:Arial;
    background:#f2f2f2;
}

.container{
    width:90%;
    max-width:600px;
    margin:40px auto;
    background:white;
    padding:20px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
}

.record{
    background:#e9f5ff;
    padding:12px;
    margin-bottom:12px;
    border-radius:8px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.record a{
    text-decoration:none;
    font-weight:bold;
    color:#007BFF;
}

button{
    background:#007bff;
    color:white;
    border:none;
    padding:8px 12px;
    border-radius:6px;
    cursor:pointer;
}

button:hover{
    background:#0056b3;
}

.no-data{
    text-align:center;
    font-size:18px;
    color:#555;
}

</style>
</head>
<body>

<div class="container">
    <h2>Your Medical Records</h2>

    <?php
    if(mysqli_num_rows($res) > 0){
        while($row = mysqli_fetch_assoc($res)){
            
            // Extract only file name (not full path)
            $fileName = basename($row['file_path']);

            echo "
            <div class='record'>
                <a href='{$row['file_path']}' target='_blank'>$fileName</a>
                <a href='{$row['file_path']}' download>
                    <button>Download</button>
                </a>
            </div>
            ";
        }
    } else {
        echo "<p class='no-data'>No Records Uploaded Yet</p>";
    }
    ?>

</div>

</body>
</html>
