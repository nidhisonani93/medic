<?php include 'header.php'; ?>
<!-------------------- STYLES -------------------->
<style>
.container-box{
    max-width: 1000px;
    margin: 40px auto;
    background: #fff;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 0 20px rgba(0,0,0,0.1);
}
.section-title{
    font-size: 30px;
    font-weight: bold;
    text-align: center;
    margin-bottom: 20px;
}
.form-grid{
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}
.form-grid input,
.form-grid select,
.form-grid textarea{
    width: 100%; padding: 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
}
.btn-book{
    grid-column: span 2;
    background: #007bff;
    padding: 12px;
    font-size: 18px;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}
.btn-book:hover{ background:#0056b3; }

@media(max-width:720px){
    .form-grid{ grid-template-columns:1fr; }
    .btn-book{ grid-column: span 1; }
}
</style>

<div class="container-box">
    <h2 class="section-title">Unified Booking Page</h2>
    <p class="text-center mb-4">Book Appointment • Order Medicine • Lab Test Booking • Emergency Request — All in One Page</p>

    <form action="process_booking.php" method="POST" class="form-grid">

        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email Address" required>
        <input type="text" name="phone" placeholder="Phone Number" required>

        <select name="booking_type" required>
            <option value="">Select Booking Type</option>
            <option value="appointment">Doctor Appointment</option>
            <option value="lab_test">Lab Test</option>
            <option value="medicine">Order Medicine</option>
            <option value="emergency">Emergency / Ambulance</option>
        </select>

        <select name="service" required>
            <option value="">Select Service</option>
            <option>General Checkup</option>
            <option>Dermatology</option>
            <option>Dental Care</option>
            <option>Eye Specialist</option>
            <option>Blood Test</option>
            <option>Full Body Checkup</option>
            <option>Order Prescription Medicine</option>
        </select>

        <input type="date" name="date" required>
        <input type="time" name="time" required>

        <textarea name="message" placeholder="Describe your issue or medicine request..."></textarea>

        <button type="submit" class="btn-book">Submit Request</button>
    </form>
</div>

<?php include 'footer.php'; ?>
