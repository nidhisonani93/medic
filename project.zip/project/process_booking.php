<?php
// DATABASE CONNECTION
$conn = new mysqli("localhost", "root", "", "medic");

if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

// RECEIVE FORM DATA
$name          = $_POST['name'];
$email         = $_POST['email'];
$phone         = $_POST['phone'];
$booking_type  = $_POST['booking_type'];
$service       = $_POST['service'];
$date          = $_POST['date'];
$time          = $_POST['time'];
$message       = $_POST['message'];

// INSERT QUERY
$sql = "INSERT INTO bookings (name,email,phone,booking_type,service,date,time,message)
        VALUES ('$name','$email','$phone','$booking_type','$service','$date','$time','$message')";

if ($conn->query($sql) === TRUE) {
    echo "<h2 style='text-align:center; color:green;'>Booking Submitted Successfully!</h2>";
    echo "<p style='text-align:center;'><a href='dashboard.php'>Go Back to Dashboard</a></p>";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
