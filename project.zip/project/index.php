<?php
// Responsive Index Page using Bootstrap 5
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Medic – Unified Digital Healthcare Platform</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f5f8ff;
        }
        .hero {
            background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('assets/img/hero.jpg');
            background-size: cover;
            background-position: center;
            color: #fff;
            height: 80vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            border-radius: 0 0 30px 30px;
        }
        .service-card:hover { transform: scale(1.05); transition: 0.3s; }
    </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">Medic</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item"><a href="index.php" class="nav-link active">Home</a></li>
                <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
                <li class="nav-item"><a href="login.php" class="nav-link">Login</a></li>
                <li class="nav-item"><a href="registration.php" class="nav-link">Register</a></li>
                <li class="nav-item"><a href="book.php" class="nav-link">book</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- HERO SECTION -->
<section class="hero">
    <div class="container">
        <h1 class="display-4 fw-bold">Unified Digital Healthcare Platform</h1>
        <p class="lead mt-3">Book Appointments • Access Health Records • Order Medicines • Emergency Assistance</p>
        <a href="registration.php" class="btn btn-light btn-lg mt-3">Get Started</a>
    </div>
</section>

<!-- SERVICES SECTION -->
<section class="py-5">
    <div class="container">
        <h2 class="text-center fw-bold mb-4">Our Services</h2>
        <div class="row g-4">
            <div class="col-md-3">
                <div class="card service-card shadow p-3 text-center">
                    <img src="download.png" height="80" class="mx-auto" />
                    <h5 class="mt-3">Health Records</h5>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card service-card shadow p-3 text-center">
                    <img src="appointment.png" height="80" class="mx-auto" />
                    <h5 class="mt-3">Appointments</h5>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card service-card shadow p-3 text-center">
                    <img src="order.png" height="80" class="mx-auto" />
                    <h5 class="mt-3">Order Medicines</h5>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card service-card shadow p-3 text-center">
                    <img src="help.png" height="80" class="mx-auto" />
                    <h5 class="mt-3">Emergency Help</h5>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FOOTER -->
<footer class="bg-primary text-white text-center p-3 mt-5">
    <p class="mb-0">© 2025 Medic Platform | All Rights Reserved</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>