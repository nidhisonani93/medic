<?php
session_start();
include "db.php";

if(isset($_POST['help'])){
    $uid = $_SESSION['user_id'];
    mysqli_query($conn,"INSERT INTO emergency(user_id,message) VALUES('$uid','Emergency Help Needed')");
    echo "<script>alert('🚨 Emergency Request Sent Successfully!');</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Emergency Help</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
    body{
        margin:0;
        padding:0;
        font-family:Arial, sans-serif;
        background:#ffe5e5;
        display:flex;
        justify-content:center;
        align-items:center;
        height:100vh;
    }

    .box{
        width:90%;
        max-width:420px;
        background:white;
        padding:30px;
        border-radius:12px;
        text-align:center;
        box-shadow:0 0 20px rgba(255,0,0,0.18);
    }

    h2{
        margin-bottom:20px;
        color:#c40000;
    }

    button{
        width:100%;
        padding:15px;
        background:red;
        color:white;
        border:none;
        font-size:18px;
        border-radius:10px;
        cursor:pointer;
        font-weight:bold;
        letter-spacing:1px;
        box-shadow:0 4px 10px rgba(255,0,0,0.3);
    }

    button:hover{
        background:#b30000;
    }

    @media(max-width:450px){
        h2{ font-size:22px; }
        button{ font-size:16px; }
    }
</style>

</head>
<body>

<div class="box">
    <h2>🚑 Emergency Help</h2>
    <p>If you need urgent help, press the button below.</p>

    <form method="POST">
        <button name="help">Send Emergency Alert</button>
    </form>
</div>

</body>
</html>
