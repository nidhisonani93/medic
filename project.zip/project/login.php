<?php
session_start();
include "db.php";

$error = "";

if(isset($_POST['login'])){
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $sql = mysqli_query($conn,"SELECT * FROM users WHERE email='$email'");
    $user = mysqli_fetch_assoc($sql);

    if($user && password_verify($pass, $user['password'])){
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name'] = $user['name'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Invalid Email or Password!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
    body{
        font-family: Arial, sans-serif;
        background: #f0f2f5;
        margin: 0;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .container{
        width: 90%;
        max-width: 400px;
        background: #fff;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 0 12px rgba(0,0,0,0.15);
    }

    h2{
        text-align: center;
        margin-bottom: 15px;
        color: #333;
    }

    label{
        font-size: 14px;
        color: #333;
    }

    input{
        width: 100%;
        padding: 10px;
        margin: 8px 0 15px;
        border: 1px solid #ccc;
        border-radius: 6px;
    }

    button{
        width: 100%;
        padding: 12px;
        background: #007bff;
        border: none;
        border-radius: 6px;
        color: white;
        font-size: 16px;
        cursor: pointer;
    }

    button:hover{
        background: #0056b3;
    }

    .error{
        color: red;
        text-align: center;
        margin-bottom: 10px;
        font-size: 14px;
    }

    @media(max-width:480px){
        .container{
            padding: 20px;
        }
    }
</style>

</head>
<body>

<div class="container">
    <h2>User Login</h2>

    <?php if($error){ ?>
        <div class="error"><?php echo $error; ?></div>
    <?php } ?>

    <form method="POST">
        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Password:</label>
        <input type="password" name="password" required>

        <button name="login">Login</button>
    </form>
</div>

</body>
</html>
