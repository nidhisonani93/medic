<?php
if(isset($_POST['order'])){
    echo "<script>alert('Medicine Order Placed Successfully!');</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Order Medicine</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
    body{
        margin:0;
        padding:0;
        font-family:Arial, sans-serif;
        background:#f1f5f9;
        display:flex;
        justify-content:center;
        align-items:center;
        height:100vh;
    }

    .card{
        width:95%;
        max-width:500px;
        background:white;
        padding:30px;
        border-radius:12px;
        box-shadow:0 0 25px rgba(0,0,0,0.1);
    }

    h2{
        text-align:center;
        margin-bottom:25px;
        font-size:26px;
    }

    label{
        font-weight:bold;
        margin-bottom:6px;
        display:block;
    }

    input{
        width:100%;
        padding:12px;
        border-radius:8px;
        border:1px solid #ccc;
        margin-bottom:18px;
        font-size:16px;
    }

    button{
        width:100%;
        padding:14px;
        border:none;
        border-radius:8px;
        background:#007bff;
        color:white;
        font-size:18px;
        cursor:pointer;
    }

    button:hover{
        background:#0056b3;
    }

    @media(max-width:450px){
        h2{ font-size:22px; }
    }
</style>
</head>

<body>

<div class="card">
    <h2>Order Medicine</h2>

    <form method="POST">
        <label>Medicine Name:</label>
        <input type="text" name="med" required>

        <label>Quantity:</label>
        <input type="number" name="qty" required>

        <button name="order">Place Order</button>
    </form>
</div>

</body>
</html>
