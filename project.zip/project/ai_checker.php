<?php
if(isset($_POST['check'])){
    $sym = strtolower($_POST['symptom']);

    if(str_contains($sym,'fever')){
        $result = "Possibility: <b>Viral Infection</b><br>Advice: Take rest & stay hydrated.";
    }
    elseif(str_contains($sym,'chest pain')){
        $result = "⚠️ <b>High Risk:</b> Consult doctor immediately!";
    }
    else{
        $result = "General Symptom. Monitor condition.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>AI Symptom Checker</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
    body{
        margin:0;
        padding:0;
        font-family:Arial, sans-serif;
        background:#f0f8ff;
        display:flex;
        justify-content:center;
        align-items:center;
        height:100vh;
    }

    .box{
        width:90%;
        max-width:430px;
        background:white;
        padding:25px;
        border-radius:12px;
        box-shadow:0 0 18px rgba(0,0,0,0.15);
        text-align:center;
    }

    h2{
        margin-bottom:20px;
        color:#0056b3;
    }

    input{
        width:100%;
        padding:12px;
        border:1px solid #ccc;
        border-radius:8px;
        margin-bottom:15px;
        font-size:16px;
    }

    button{
        width:100%;
        padding:14px;
        background:#007bff;
        color:white;
        border:none;
        font-size:17px;
        border-radius:8px;
        cursor:pointer;
        font-weight:bold;
        letter-spacing:1px;
    }

    button:hover{
        background:#0056b3;
    }

    .result-box{
        background:#e8f4ff;
        padding:12px;
        border-radius:8px;
        margin-top:15px;
        font-size:16px;
        color:#003f7f;
        border-left:4px solid #007bff;
    }

    @media(max-width:450px){
        h2{ font-size:22px; }
        button{ font-size:16px; }
    }
</style>

</head>
<body>

<div class="box">
    <h2>🤖 AI Symptom Checker</h2>

    <form method="POST">
        <input type="text" name="symptom" placeholder="Enter your symptom..." required>
        <button name="check">Check</button>
    </form>

    <?php if(isset($result)){ ?>
        <div class="result-box"><?php echo $result; ?></div>
    <?php } ?>
</div>

</body>
</html>
