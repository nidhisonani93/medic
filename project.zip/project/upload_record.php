<?php
session_start();
include "db.php";

if(isset($_POST['upload'])){
    $uid = $_SESSION['user_id'];

    $file = $_FILES['file']['name'];
    $path = "uploads/".$file;

    move_uploaded_file($_FILES['file']['tmp_name'], $path);

    mysqli_query($conn,"INSERT INTO records(user_id,file_path) VALUES('$uid','$path')");
    echo "<script>alert('Record Uploaded Successfully!');</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Upload Medical Record</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
    

    .container{
        width:90%;
        max-width:400px;
        background:white;
        padding:20px;
        margin:60px auto;
        border-radius:10px;
        box-shadow:0 0 15px rgba(0,0,0,0.2);
    }

    h2{
        text-align:center;
        margin-bottom:15px;
    }

    input[type=file]{
        width:100%;
        padding:10px;
        border:1px solid #ccc;
        border-radius:8px;
        margin-bottom:15px;
    }

    button{
        width:100%;
        padding:12px;
        background:#007bff;
        color:white;
        border:none;
        border-radius:8px;
        font-size:16px;
        cursor:pointer;
    }

    button:hover{
        background:#0056b3;
    }

    @media(max-width:500px){
        .container{
            margin-top:40px;
            padding:15px;
        }
        button{
            font-size:15px;
        }
    }
</style>
</head>
<body>

<div class="container">
    <h2>Upload Medical Record</h2>

    <form method="POST" enctype="multipart/form-data">
        <label>Select File:</label>
        <input type="file" name="file" required>
        <button name="upload">Upload</button>
    </form>
</div>

</body>
</html>
