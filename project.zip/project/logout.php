<?php
session_start();
session_unset();
session_destroy();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Logout</title>
    <style>
        body {
            font-family: Arial;
            background: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .box {
            background: white;
            padding: 25px;
            width: 90%;
            max-width: 350px;
            text-align: center;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
        }

        h2 {
            color: #333;
        }

        .btn {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .btn:hover {
            background: #0056b3;
        }

        @media(max-width:480px){
            .box {
                width: 95%;
            }
        }
    </style>
</head>
<body>

<div class="box">
    <h2>You have been logged out</h2>
    <p>Redirecting to login page...</p>
    <a class="btn" href="login.php">Go to Login</a>
</div>

<script>
    setTimeout(() => {
        window.location.href = "login.php";
    }, 2000);
</script>

</body>
</html>
